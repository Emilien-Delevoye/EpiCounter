--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.10
-- Dumped by pg_dump version 9.6.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: _todo; Type: TABLE; Schema: public; Owner: rebasedata
--

CREATE TABLE public._todo (
    id smallint,
    content character varying(5) DEFAULT NULL::character varying,
    date_created character varying(10) DEFAULT NULL::character varying
);


ALTER TABLE public._todo OWNER TO rebasedata;

--
-- Data for Name: _todo; Type: TABLE DATA; Schema: public; Owner: rebasedata
--

COPY public._todo (id, content, date_created) FROM stdin;
10	yo	2020-08-14
11	hello	2020-08-14
12	hello	2020-08-14
13	hello	2020-08-14
14	hello	2020-08-14
15	hello	2020-08-14
16	waouh	2020-08-14
17	waouh	2020-08-14
18		2020-08-14
19		2020-08-14
20	ef	2020-08-14
21	rg	2020-08-14
22	waouh	2020-08-14
23	waouh	2020-08-14
\.


--
-- PostgreSQL database dump complete
--

